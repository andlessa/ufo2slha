#ifndef s_guard
#define s_guard
#include <complex>
void sxxxxx(double p[4],int nss,std::complex<double> sc[3]);
#endif
