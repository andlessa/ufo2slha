#include "LHAFortran_aMCatNLO.h"
#include "pythia8_fortran.cc"
